Create Database MyJsp
Create Table NewAccounts
(
	UserName char(20) not null,
	Password varchar(30) not null,
	CustomerName varchar(20) not null,
	Email varchar(20) not null
)
Select * from NewAccounts